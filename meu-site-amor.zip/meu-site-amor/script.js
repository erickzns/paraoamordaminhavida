// Aqui você pode adicionar interatividade depois, como animações ou mensagens
console.log("Site feito com ❤️");